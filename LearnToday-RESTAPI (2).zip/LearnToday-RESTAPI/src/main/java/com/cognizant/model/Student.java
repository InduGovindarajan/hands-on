package com.cognizant.model;

public class Student {

	private int EnrollmentId;
	private int StudentId;
	private int CourseId;
	private Course course;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public int getEnrollmentId() {
		return EnrollmentId;
	}
	public void setEnrollmentId(int enrollmentId) {
		EnrollmentId = enrollmentId;
	}
	public int getStudentId() {
		return StudentId;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public int getCourseId() {
		return CourseId;
	}
	public void setCourseId(int courseId) {
		CourseId = courseId;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Student [EnrollmentId=" + EnrollmentId + ", StudentId=" + StudentId + ", CourseId=" + CourseId
				+ ", course=" + course + "]";
	}
	
}
