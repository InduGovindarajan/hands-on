package com.cognizant.model;

public class Trainer {

	private int TrainerId;
	private String Password;
	public Trainer() {
		// TODO Auto-generated constructor stub
	}

	public int getTrainerId() {
		return TrainerId;
	}
	public void setTrainerId(int trainerId) {
		TrainerId = trainerId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	@Override
	public String toString() {
		return "Trainer [TrainerId=" + TrainerId + ", Password=" + Password + "]";
	}
	
}
