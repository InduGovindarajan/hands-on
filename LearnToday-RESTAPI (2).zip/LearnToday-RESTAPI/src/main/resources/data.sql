INSERT INTO Course(CourseId,Title,Fees,Description,Trainer,Star_Date) values(1001,'.NET Core',9000.0,'.NET Core is a framework used for creating cross platform application','Joe','2021-02-27T00:00:00');
INSERT INTO Student(EnrollmetId,StudentId,CourseId) values(1,01,1001);
INSERT INTO Course(TrainerId,Password) values(100,'Password');
