DROP TABLE Course IF EXISTS;
CREATE TABLE Course(CourseId int, Title varchar(200), Fees float, Description varchar(max), Trainer varchar(100),Star_Date date );

DROP TABLE Student IF EXISTS;
CREATE TABLE Student(EnrollmetId int, StudentId int,CourseId int);

DROP TABLE Course IF EXISTS;
CREATE TABLE Course(TrainerId int,Password varchar(max) );
